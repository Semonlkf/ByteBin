package com.zyq.bloggy.aspect;

public enum LogType {
    INFO, ERROR
}
